import time
from threading import Thread

from twitch_chat_monitor import TwitchChatMonitor
from twitch_connected_monitor import TwitchConnectedMonitor
from chat_info_storage import ChatStorage
from main_storage import MainStorage
from configuration import Configuration

from log import Log

LOG_SAVE = False
LOG_GATHER = False


class TwitchCredentials:
    def __init__(self, username, password):
        self.username = username
        self.password = password


class MonitorOrchestrator(Thread):
    def __init__(self, credentials, channel: str):
        Thread.__init__(self, name="Orchestrator", daemon=True)

        self.credentials = credentials
        self.channel = channel

        self.chat_monitor = TwitchChatMonitor(
            credentials.username,
            credentials.password,
            channel,
            name="Chat Monitor")
        self.presence_monitor = TwitchConnectedMonitor(
            channel,
            name="Presence Monitor"
        )

        self.last_message_timestamp = dict()
        self.last_presence_timestamp = dict()
        self.last_online_timestamp = dict()
        self.viewers_count = dict()
        self.titles = dict()
        self.games = dict()
        self.storage = None
        self.main_storage = None

    def run(self):
        self.storage = ChatStorage()
        self.main_storage = MainStorage()

        self.presence_monitor.start()
        self.chat_monitor.start()

        iterations = 0
        while True:
            if iterations % Configuration.OrchestratorGatherTime == 0:
                try:
                    self.gather_info()
                except Exception as e:
                    pass

            if iterations % Configuration.OrchestratorIterationsSavingInterval == 0:
                try:
                    self.save_info()
                except Exception as e:
                    pass

            iterations += 1
            time.sleep(1)

    def gather_info(self):
        for channel, data in self.chat_monitor.last_message_timestamp.items():
            self.last_message_timestamp[channel] = data

        for channel, data in self.presence_monitor.last_presence.items():
            self.last_presence_timestamp[channel] = data

        for channel, last_online in self.presence_monitor.last_online.items():
            self.last_online_timestamp[channel] = last_online

        for channel, count in self.presence_monitor.viewers_count.items():
            self.viewers_count[channel] = count

        for channel, game in self.presence_monitor.games.items():
            self.games[channel] = game

        for channel, title in self.presence_monitor.stream_titles.items():
            self.titles[channel] = title

    def save_info(self):
        for channel, channel_data in self.last_message_timestamp.items():
            for user in set(channel_data.keys()):
                timestamp = channel_data[user]
                self.storage.update_latest_message(user, channel, timestamp)

        for channel, channel_data in self.last_presence_timestamp.items():
            for user in set(channel_data.keys()):
                timestamp = channel_data[user]
                self.storage.update_latest_presence(user, channel, timestamp)

        for channel, timestamp in self.last_online_timestamp.items():
            self.storage.update_last_online(channel, timestamp)

        for channel, count in self.viewers_count.items():
            self.storage.update_viewers_count(channel, count)

        for channel, game in self.games.items():
            self.storage.update_latest_game(channel, game)

        for channel, title in self.titles.items():
            self.storage.set_stream_title(channel, title)
