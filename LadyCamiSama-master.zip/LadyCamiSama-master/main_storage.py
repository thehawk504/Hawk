from configuration import Configuration
import mysql.connector
from threading import RLock

# import mysqlclient

"""
GRANT ALL PRIVILEGES ON *.* TO 'ladycamisama_bot'@'localhost' IDENTIFIED BY 'ladycamisama';
"""


class MainStorage:
    _users = dict()
    _points = dict()
    lock = RLock()

    def __init__(self):
        try:
            self.db = mysql.connector.connect(
                host="localhost",
                user=Configuration.DBUsername,
                passwd=Configuration.DBPassword,
                database=Configuration.DBName
            )

            cur = self.get_cursor()
            cur.execute("SET NAMES utf8mb4")
            cur.execute("SET CHARACTER SET utf8mb4")
            cur.execute("SET character_set_connection=utf8mb4")
            cur.close()

            self._load_points()
        except mysql.connector.errors.ProgrammingError as e:
            if "1049" in str(e):
                db = mysql.connector.connect(
                    host="localhost",
                    user=Configuration.DBUsername,
                    passwd=Configuration.DBPassword
                )
                cur = db.cursor()
                cur.execute("CREATE DATABASE {}".format(Configuration.DBName))
                cur.close()
                db.close()
                self.__init__()
            else:
                raise e

    def get_cursor(self, retry=True):
        try:
            cursor = self.db.cursor()
            return cursor
        except Exception as e:
            if retry:
                self.db = mysql.connector.connect(
                    host="localhost",
                    user=Configuration.DBUsername,
                    passwd=Configuration.DBPassword,
                    database=Configuration.DBName
                )
                return self.get_cursor(retry=False)
            else:
                raise e

    def _load_points(self):
        SQL = "SELECT User, Count FROM Points"
        cur = self.get_cursor()
        cur.execute(SQL)
        results = cur.fetchall()
        self.db.commit()
        cur.close()
        if not results:
            return

        for user, count in results:
            MainStorage._points[user] = count

    def add_user(self, did, twitch_username):
        SQL = "INSERT INTO Users (Discord, Twitch) VALUES (%s, %s)"
        cur = self.get_cursor()
        cur.execute(SQL, (did, twitch_username))
        cur.close()
        self.db.commit()

        MainStorage._users[did] = twitch_username

    def _get_twitch_username_db(self, did):
        SQL = "SELECT Twitch FROM Users WHERE Discord = %s"
        cur = self.get_cursor()
        cur.execute(SQL, (did,))
        result = cur.fetchone()
        self.db.commit()
        cur.close()
        if not result:
            return None

        return result[0]

    def _get_discord_db(self, tuser):
        SQL = "SELECT Discord FROM Users WHERE Twitch = %s"
        cur = self.get_cursor()
        cur.execute(SQL, (tuser,))
        result = cur.fetchone()
        self.db.commit()
        cur.close()
        if not result:
            return None

        return result[0]

    def get_twitch_username(self, did):
        if did in MainStorage._users:
            return MainStorage._users[did]

        tuser = self._get_twitch_username_db(did)

        if tuser:
            MainStorage._users[did] = tuser

        return tuser

    def get_discord_id(self, tuser):
        for did, twitch in MainStorage._users.items():
            if twitch == tuser:
                return did

        return self._get_discord_db(tuser)

    def reset_twitch_username(self, did):
        SQL = "DELETE FROM Users WHERE Discord = %s"
        cur = self.get_cursor()
        cur.execute(SQL, (did,))
        cur.close()
        self.db.commit()

        if did in MainStorage._users:
            del MainStorage._users[did]

    def _set_points_db(self, did: int, count: int):
        SQL_I = "INSERT INTO Points (User, Count) VALUES (%s, %s)"
        SQL_U = "UPDATE Points SET Count = %s WHERE User = %s"
        cur = self.get_cursor()
        try:
            cur.execute(SQL_I, (did, count))
        except mysql.connector.IntegrityError:
            cur.execute(SQL_U, (count, did))
        cur.close()
        self.db.commit()

    def get_points_count(self, did: int):
        SQL = "SELECT Count FROM Points WHERE User = %s"
        cur = self.get_cursor()
        cur.execute(SQL, (did,))
        result = cur.fetchone()
        self.db.commit()
        cur.close()
        if not result:
            return 0

        return result[0]

    def add_points(self, did: int, count: int):
        with MainStorage.lock:
            if did not in MainStorage._points:
                current_count = self.get_points_count(did)
            else:
                current_count = MainStorage._points[did]

            MainStorage._points[did] = current_count + count
            self._set_points_db(did, current_count + count)

    def remove_points(self, did: int, count: int, allow_negative: bool = False):
        with MainStorage.lock:
            if did not in MainStorage._points:
                current_count = self.get_points_count(did)
            else:
                current_count = MainStorage._points[did]

            new_count = current_count - count
            if new_count < 0 and not allow_negative:
                new_count = 0

            MainStorage._points[did] = new_count
            self._set_points_db(did, new_count)

    def delete_points(self, did: int):
        with MainStorage.lock:
            if did in MainStorage._points:
                del MainStorage._points[did]

            SQL = "DELETE FROM Points WHERE User = %s"
            cur = self.db.cursor()
            cur.execute(SQL, (did, ))
            self.db.commit()
            cur.close()

    def reset_all_points(self):
        with MainStorage.lock:
            SQL = "UPDATE Points SET Count = 0"
            cur = self.get_cursor()
            cur.execute(SQL)
            cur.close()
            self.db.commit()
            self._load_points()

    def divide_all(self, divider):
        with MainStorage.lock:
            assert isinstance(divider, float)
            SQL = "UPDATE Points SET Count = Count / {}".format(divider)
            cur = self.get_cursor()
            cur.execute(SQL)
            cur.close()
            self.db.commit()
            self._load_points()

    def all_twitchs_channels(self):
        SQL = "SELECT Discord, Twitch FROM Users"
        cur = self.get_cursor()
        cur.execute(SQL)
        results = cur.fetchall()
        self.db.commit()
        cur.close()
        if not results:
            return list()

        l = list()
        for did, username in results:
            l.append(username)
            MainStorage._users[did] = username

        return l

    def get_points_dict(self):
        return {user: points for user, points in MainStorage._points.items()}

    def delete_data(self, did):
        self.reset_twitch_username(did)
        self.delete_points(did)
