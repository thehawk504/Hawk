import time
import asyncio

from discord.ext import commands
import discord

from chat_info_storage import ChatStorage
from main_storage import MainStorage
from configuration import Configuration

from log import Log
import utils


class ScoreCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.guild: discord.Guild = None

        self.storage = ChatStorage()
        self.main_storage = MainStorage()

        self.system_channel = None
        self.current_ranks = dict()
        self.next_ranks = dict()

        self.distribute_cog = None

        self.points_channels = list()
        self.points_for_channels = dict()
        self.last_messages = dict()

    @commands.Cog.listener()
    async def on_ready(self):
        self.guild = self.bot.guilds[0]

        if Configuration.SystemChannelID:
            self.system_channel = self.guild.get_channel(Configuration.SystemChannelID)

        for points_channel_id, points in Configuration.PointsChannels:
            channel = self.guild.get_channel(points_channel_id)
            self.points_channels.append(channel)
            self.points_for_channels[channel] = points
            self.last_messages[channel] = dict()

        loop = self.bot.loop
        task = loop.create_task(self.periodic())
        asyncio.ensure_future(task, loop=loop)

        self.distribute_cog = self.bot.get_cog("Distribute")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.channel in self.points_channels:
            self.last_messages[message.channel][message.author] = time.time()

    async def periodic(self):
        while True:
            await self.update_current_ranks()
            await self.update_next_ranks()
            await self.update_points()
            await asyncio.sleep(Configuration.PointsAttributionTime)

    async def update_current_ranks(self):
        for member in self.guild.members:
            tuser = self.main_storage.get_twitch_username(member.id)
            if not tuser:
                continue

            self.current_ranks[tuser] = None
            self.current_ranks[member.id] = None
            for r in self.guild.roles:
                if r.id in Configuration.Roles:
                    self.current_ranks[tuser] = r
                    self.current_ranks[member.id] = r
                    break

    async def update_next_ranks(self):
        role_ids = list(Configuration.Roles)
        role_ids.sort(key=lambda role_id: -1 * Configuration.Roles[role_id])
        for i, role_id in enumerate(role_ids):
            if i == len(Configuration.Roles) - 1:
                self.next_ranks[role_id] = self.guild.get_role(role_id)
            else:
                self.next_ranks[role_id] = self.guild.get_role(role_ids[i + 1])

    async def update_points(self):
        roles = dict()

        for role_id in Configuration.Roles:
            roles[role_id] = self.guild.get_role(role_id)

        views = [
            self.guild.get_member(did)
            for did in
            [
                self.main_storage.get_discord_id(tuser)
                for tuser, *_ in
                self.storage.get_current_viewers(max_time=120)
            ]
            if did is not None
        ]
        chats = [
            self.guild.get_member(did)
            for did in
            [
                self.main_storage.get_discord_id(tuser)
                for tuser, *_ in
                self.storage.get_current_chatters(max_time=120)
            ]
            if did is not None
        ]

        for v in views:
            self.main_storage.add_points(v.id, Configuration.PresencePoints)

        for c in chats:
            self.main_storage.add_points(c.id, Configuration.ChattingPoints)

        for channel in self.last_messages:
            for user, timestamp in self.last_messages[channel].items():
                if time.time() - timestamp <= 60:
                    self.main_storage.add_points(user.id, self.points_for_channels[channel])

    @commands.command()
    async def viewsraw(self, ctx, max_time: int):
        views = self.storage.get_current_viewers(max_time=max_time)
        await ctx.send(str(list(views)))

    @commands.command()
    async def chatsraw(self, ctx, max_time: int):
        chats = self.storage.get_current_chatters(max_time=max_time)
        await ctx.send(str(list(chats)))

    @commands.command()
    async def views(self, ctx):
        views = self.storage.get_current_viewers(max_time=120)
        viewers = list()
        for tuser in views:
            did = self.main_storage.get_discord_id(tuser)
            if did:
                viewers.append(self.guild.get_member(did))

        chats = self.storage.get_current_chatters(max_time=120)
        chatters = list()
        for tuser in chats:
            did = self.main_storage.get_discord_id(tuser)
            if did:
                chatters.append(self.guild.get_member(did))

        e = discord.Embed(
            title="Current viewers"
        )
        e.add_field(
            name="Viewers",
            value="- " + "\n- ".join(map(lambda m: m.name, viewers)) if viewers else "None"
        )
        e.add_field(
            name="Chatters",
            value="- " + "\n- ".join(map(lambda m: m.name, chatters)) if chatters else "None"
        )
        await ctx.send(embed=e)

    @commands.command()
    async def ranked(self, ctx, rank: str = None):
        if not rank:
            return

        role = None
        for r in self.guild.roles:
            if r.name.lower() == rank.lower():
                role = r
                break

        if not role:
            await ctx.send("This rank doesn't exist.")
            return

        msg = "Members with rank {}".format(role.name)
        for m in self.guild.members:
            if role in m.roles:
                msg += "\n- {} ({} points)".format(m.mention, self.main_storage.get_points_count(m.id))
        await ctx.send(msg)

    @commands.command(aliases=["score", "tier"])
    async def points(self, ctx, member: discord.Member = None):
        author: discord.Member = ctx.message.author

        if not member:
            member = author

        tuser = self.main_storage.get_twitch_username(member.id)
        if not tuser:
            await ctx.send("{} Please register with `!twitch` first!".format(member.mention))
            return

        points = self.main_storage.get_points_count(member.id)

        # Get current rank
        role: discord.Role = None
        for r in member.roles:
            if r.id in Configuration.Roles:
                role = r
                break

        if not role:
            Log.warning("Points", "Couldn't find role for {}".format(member))

        next_rank: discord.Role = None
        if role:
            next_rank = self.next_ranks.get(role.id, None)

        leaderboard_rank: int = self.distribute_cog.leaderboard_rank.get(member.id, "Bot starting")

        if next_rank != role:
            members_with_next_rank = [
                m for m
                in self.guild.members
                if next_rank in m.roles
            ]
            members_with_next_rank.sort(key=lambda m: self.main_storage.get_points_count(m.id))
            if members_with_next_rank:
                min_points_next_rank = min(
                    [self.main_storage.get_points_count(member.id) for member in members_with_next_rank])
                points_to_next_rank = min_points_next_rank - points
            else:
                min_points_next_rank = "[No user in higher rank]"
                points_to_next_rank = "[No user in higher rank]"

            await ctx.send(Configuration.PointsString.format(
                user=member.mention,
                rank=role,
                points=points,
                points_missing=points_to_next_rank,
                min_points_next_rank=min_points_next_rank,
                next_rank=next_rank,
                leaderboard_rank=leaderboard_rank,
                leaderboard_total=self.distribute_cog.leaderboard_count
            ))
        elif role:
            if leaderboard_rank == 1:
                await ctx.send(
                    "{user} You are {rank}. You have {points} points. You're on the top, keep going!.".format(
                        user=member.mention,
                        rank=role,
                        points=points
                    ))
            else:
                await ctx.send(
                    "{user} You are {rank}. You have {points} points. You are {leaderboard_rank} / {leaderboard_total}.".format(
                        user=member.mention,
                        rank=role,
                        points=points,
                        leaderboard_rank=leaderboard_rank,
                        leaderboard_total=self.distribute_cog.leaderboard_count
                    ))

        else:
            await ctx.send("{user} You have {points} points, you're not ranked yet!".format(
                user=member.mention,
                points=points
            ))

    @commands.command()
    async def add(self, ctx, user: discord.Member, points: int):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        self.main_storage.add_points(user.id, points)
        await ctx.send("New count: {}".format(self.main_storage.get_points_count(user.id)))

    @commands.command(aliases=["substract"])
    async def remove(self, ctx, user: discord.Member, points: int):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        self.main_storage.remove_points(user.id, points)
        await ctx.send("New count: {}".format(self.main_storage.get_points_count(user.id)))

    @commands.command(aliases=['divide'])
    async def divideall(self, ctx, divider: float):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        self.main_storage.divide_all(divider)
        await ctx.send("All points have been divided by {}".format(divider))

    @commands.command()
    async def tuser(self, ctx, user: discord.Member):
        tuser = self.main_storage.get_twitch_username(user.id)
        await ctx.send(tuser if tuser else "None")


def setup(bot: commands.Bot):
    bot.add_cog(ScoreCog(bot))
