from discord.ext import commands
import discord

from configuration import Configuration


class WelcomeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.guild: discord.Guild = None
        self.welcome_channel: discord.TextChannel = None
        self.log_channel: discord.TextChannel = None

    @commands.Cog.listener()
    async def on_ready(self):
        self.guild = self.bot.guilds[0]

        self.log_channel = self.guild.get_channel(Configuration.LogChannelID)
        self.welcome_channel = self.guild.get_channel(Configuration.WelcomeChannelID)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        await self.channel.send(Configuration.WelcomeMessage.format(
            mention=member.mention
        ))

        await self.log_channel.send("Member {} joined.".format(str(member)))

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        await self.log_channel.send("Member {} left.".format(str(member)))


def setup(bot):
    bot.add_cog(WelcomeCog(bot))
