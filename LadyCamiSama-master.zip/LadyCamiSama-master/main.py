# ADD TO SERVER LINK
# https://discordapp.com/oauth2/authorize?client_id=567599923676053504&scope=bot&permissions=8
# python3 -m pip install -U git+https://github.com/Rapptz/discord.py@rewrite#egg=discord.py[voice]

import sys
from log import Log
from configuration import Configuration, TwitchConfiguration
from main_storage import MainStorage
from monitor_orchestrator import MonitorOrchestrator, TwitchCredentials
import utils
import discord
from discord.ext import commands
import time


main_storage = MainStorage()
client: commands.Bot = commands.Bot(command_prefix="!")
monitor = MonitorOrchestrator(TwitchConfiguration(), channel=Configuration.TwitchChannelName)
monitor.start()


@client.event
async def on_ready():
    assert client.guilds, "Bot should be in a guild."
    assert len(client.guilds) == 1, "Bot should be in at most one guild."

    Log.info("Main", "Using discord.py version {}".format(discord.__version__))
    Log.info("Main", "Logged in as {}#{} ({})".format(client.user.name, client.user.discriminator, client.user.id))
    Log.info("Main", "Current guild: {}".format(client.guilds[0]))
    print("Connected to Discord and ready!")


@client.event
async def on_message(message: discord.Message):
    if message.author == client.user:
        return

    if isinstance(message.channel, discord.DMChannel):
        return

    content = message.content
    channel = message.channel

    if not content.startswith("!"):
        if Configuration.UserCommandsChannels and channel.id in Configuration.UserCommandsChannels:
            await message.delete()

    if Configuration.UserCommandsChannels:
        if channel.id not in Configuration.UserCommandsChannels:
            return

    await client.process_commands(message)


@client.event
async def on_command_error(ctx, error):
    if ctx.command:
        Log.error("Commands", "Error in: {}: {}".format(ctx.command.name, error))
        raise error


@client.event
async def on_command(ctx):
    pass


@client.event
async def on_command_completion(ctx):
    pass

cogs = (
    "registration",
    "distribute",
    "points",
    "config",
    "welcome",
    "announcements",
)
for cog in cogs:
    client.load_extension(cog)

while True:
    try:
        Log.info("Main", "Connecting to Discord")
        client.loop.run_until_complete(client.start(utils.load_token(), reconnect=True))
    except (InterruptedError, KeyboardInterrupt):
        Log.info("Main", "User interrupted bot.")
        sys.exit(0)
    except BaseException:
        Log.error("Main", "Lost connection to Discord. Reconnecting in 5s.")
        time.sleep(5)
