import json
import datetime
import time

import discord
from discord.ext import commands


def load_token():
    with open("token.json") as f:
        j = json.load(f)

    token = j["token"]
    return token


def split_long_message(m):
    if len(m) <= 2000:
        return [m]

    raw_lines = m.split("\n")
    messages = list()
    message = ""

    lines = list()
    for l in raw_lines:
        while len(l) > 500:
            lines.append(l[:500])
            l = l[500:]

        lines.append(l)

    for l in lines:
        if len(message) + len(l) + 3 > 2000:
            messages.append(message + "```")
            message = "```" + l + "\n"

        message += l + "\n"

    messages.append(message)
    return messages


def create_mention(user_id):
    return "<@{}>".format(user_id)


def date_from_timestamp(timestamp):
    dt = datetime.datetime.fromtimestamp(timestamp)
    return dt.strftime("%m/%d")


def time_from_timestamp(timestamp):
    dt = datetime.datetime.fromtimestamp(timestamp)
    return dt.strftime("%H:%M")


def is_owner(ctx):
    guild = ctx.message.guild
    author = ctx.message.author
    member = guild.get_member(author.id)
    return guild.owner == member


def is_developer(ctx):
    if isinstance(ctx, discord.Member) or isinstance(ctx, discord.User):
        return ctx.id == 181706474261708800
    elif isinstance(ctx, commands.Context):
        return is_developer(ctx.message.author)


def is_admin(ctx):
    guild = ctx.message.guild
    author = ctx.message.author
    member = guild.get_member(author.id)
    return member.guild_permissions.administrator
