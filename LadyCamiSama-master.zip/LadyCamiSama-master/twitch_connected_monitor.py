from typing import List, Dict
import json
import datetime
import time
from threading import Thread
import random

from requests import Session
import requests

from configuration import Configuration
from log import Log
from twitch_utils import TwitchUtils

session = Session()

DEBUG_ONLINE = True


class TwitchConnectedMonitor(Thread):
    URL = "https://tmi.twitch.tv/group/user/{streamer}/chatters"

    def __init__(self, channel, name=None):
        Thread.__init__(self, name=name, daemon=True)

        self.channel = channel

        self.last_presence: Dict[str, Dict[str, float]] = dict()
        self.last_online: Dict[str, float] = dict()
        self.viewers_count: Dict[str, int] = dict()
        self.games: Dict[str, int] = dict()
        self.stream_titles: Dict[str, str] = dict()

        self.twitch_utils = TwitchUtils()

    def run(self):
        last_timestamp = None
        while True:
            try:
                self.task()
                if int(time.time()) % Configuration.ConnectedRefreshInterval == 0 and last_timestamp != int(time.time()):
                    self.update_online()
                    last_timestamp = int(time.time())
            except Exception as e:
                Log.error("Presence", "Exception in {}: {}".format(self.name, repr(e)))
                raise e

            time.sleep(1)

    def update_online(self):
        to_update = [self.channel]

        result = self.twitch_utils.channels_online(to_update)
        for channel, (online, viewers, game_id, stream_title) in result.items():
            if online is None:
                self.last_online[channel] = time.time()
            elif online:
                self.last_online[channel.lower()] = time.time()
                self.viewers_count[channel] = viewers
                self.games[channel] = game_id
                self.stream_titles[channel] = stream_title

    def task(self):
        last_presence_before = dict()
        for channel, data in self.last_presence.items():
            last_presence_before[channel] = list()
            for user in data:
                last_presence_before[channel].append(user)

        channel = self.channel
        url = TwitchConnectedMonitor.URL.format(streamer=self.channel)
        try:
            req = session.get(url)
        except requests.exceptions.ConnectionError as e:
            Log.error("Presence", "Couldn't get channel data for {}: {}".format(channel, e))
            return

        data = req.text
        if "404" in data:
            return

        if not data:
            return

        try:
            data = req.json()
        except json.JSONDecodeError:
            return

        if "chatters" not in data:
            return

        chatters = data["chatters"]

        if channel not in self.last_presence:
            self.last_presence[channel] = dict()

        online = time.time() - self.last_online.get(channel, 0) <= 120
        if not online:
            return

        for chatter_type in ("vips", "moderators", "staff", "admins", "global_mods", "viewers"):
            chatter_list = chatters[chatter_type]
            for chatter in chatter_list:
                if chatter != channel:
                    self.last_presence[channel][chatter] = time.time()

        time.sleep(Configuration.PresenceMonitorTimeout)
