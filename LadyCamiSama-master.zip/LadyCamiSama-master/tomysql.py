import sqlite3
import mysql.connector

from configuration import Configuration


class Upgrader:
    def __init__(self, username, password, dbname):
        self.username = username
        self.password = password
        self.dbname = dbname
        self.chat = sqlite3.connect("chat.db")
        self.main = sqlite3.connect("users.db")
        self.init_mysql()
        self.db = None
        self.init_mysql()

    def do(self):
        self.create_tables()
        self.upgrade_messages()
        self.upgrade_gamedata()
        self.upgrade_games()
        self.upgrade_online()
        self.upgrade_presence()
        self.upgrade_viewers()
        self.upgrade_users()
        self.upgrade_points()
        self.db.commit()

    def drop(self):
        print("Dropping database")
        cur = self.db.cursor()
        cur.execute("DROP DATABASE " + self.dbname)
        cur.close()
        self.db.commit()
        self.init_mysql()

    def init_mysql(self):
        try:
            self.db = mysql.connector.connect(
                host="localhost",
                user=self.username,
                passwd=self.password,
                database=self.dbname
            )
            self.create_tables()
        except mysql.connector.errors.ProgrammingError as e:
            if "1049" in str(e):
                print("Creating DB")
                db = mysql.connector.connect(
                    host="localhost",
                    user=self.username,
                    passwd=self.password
                )
                cur = db.cursor()
                cur.execute("CREATE DATABASE {}".format(self.dbname))
                cur.close()
                db.close()
                return self.init_mysql()
            else:
                raise e

    def create_tables(self):
        SQL = [
            "CREATE TABLE IF NOT EXISTS Messages (User VARCHAR(90), Channel VARCHAR(90), Message BIGINT UNSIGNED, PRIMARY KEY (User, Channel))",
            "CREATE TABLE IF NOT EXISTS Presence (User VARCHAR(90), Channel VARCHAR(90), Timestamp BIGINT UNSIGNED, PRIMARY KEY (User, Channel))",
            "CREATE TABLE IF NOT EXISTS Online   (Channel VARCHAR(90), Timestamp BIGINT UNSIGNED, PRIMARY KEY(Channel))",
            "CREATE TABLE IF NOT EXISTS Viewers  (Channel VARCHAR(90), Viewers BIGINT UNSIGNED, PRIMARY KEY(Channel))",
            "CREATE TABLE IF NOT EXISTS Games    (Channel VARCHAR(90), Game BIGINT UNSIGNED, PRIMARY KEY(Channel))",
            "CREATE TABLE IF NOT EXISTS GameData (ID BIGINT UNSIGNED, Name VARCHAR(90), PRIMARY KEY(ID))",

            "CREATE TABLE IF NOT EXISTS Users (Discord BIGINT UNSIGNED, Twitch VARCHAR(90), PRIMARY KEY(Discord))",
            "CREATE TABLE IF NOT EXISTS Points (User BIGINT UNSIGNED, Count BIGINT UNSIGNED, PRIMARY KEY(User))",
        ]

        cur = self.db.cursor()
        for sql in SQL:
            cur.execute(sql)
        self.db.commit()

    def upgrade_messages(self):
        cur = self.chat.cursor()
        cur.execute("SELECT User, Channel, Message FROM Messages")
        results = cur.fetchall()
        cur.close()
        if not results:
            print("Empty table: Messages")
            return

        cur = self.db.cursor()
        for tup in results:
            cur.execute("INSERT IGNORE INTO Messages(User, Channel, Message) VALUES (%s, %s, %s)", tup)
        cur.close()
        self.db.commit()

    def upgrade_presence(self):
        # Presence (User VARCHAR(90), Channel VARCHAR(90), Timestamp BIGINT UNSIGNED, PRIMARY KEY (User, Channel))",
        cur = self.chat.cursor()
        cur.execute("SELECT User, Channel, Timestamp FROM Presence")
        results = cur.fetchall()
        cur.close()
        if not results:
            print("Empty table: Presence")
            return

        cur = self.db.cursor()
        for tup in results:
            cur.execute("INSERT INTO Presence(User, Channel, Timestamp) VALUES (%s, %s, %s)", tup)
        cur.close()
        self.db.commit()

    def upgrade_online(self):
        # VARCHAR(90), Timestamp BIGINT UNSIGNED, PRIMARY KEY(Channel))",
        cur = self.chat.cursor()
        cur.execute("SELECT Channel, Timestamp FROM Online")
        results = cur.fetchall()
        cur.close()
        if not results:
            print("Empty table: Online")
            return

        cur = self.db.cursor()
        for tup in results:
            cur.execute("INSERT IGNORE INTO Online(Channel, Timestamp) VALUES (%s, %s)", tup)
        cur.close()
        self.db.commit()

    def upgrade_viewers(self):
        # Viewers  (Channel VARCHAR(90), Viewers BIGINT UNSIGNED, PRIMARY KEY(Channel))",
        cur = self.chat.cursor()
        cur.execute("SELECT Channel, Viewers FROM Viewers")
        results = cur.fetchall()
        cur.close()
        if not results:
            print("Empty table: Viewers")
            return

        cur = self.db.cursor()
        for tup in results:
            cur.execute("INSERT INTO Viewers(Channel, Viewers) VALUES (%s, %s)", tup)
        cur.close()
        self.db.commit()

    def upgrade_games(self):
        # Games    (Channel VARCHAR(90), Game BIGINT UNSIGNED, PRIMARY KEY(Channel))",
        cur = self.chat.cursor()
        cur.execute("SELECT Channel, Game FROM Games")
        results = cur.fetchall()
        cur.close()
        if not results:
            print("Empty table: Games")
            return

        cur = self.db.cursor()
        for tup in results:
            cur.execute("INSERT INTO Games(Channel, Game) VALUES (%s, %s)", tup)
        cur.close()
        self.db.commit()

    def upgrade_gamedata(self):
        # GameData (ID BIGINT UNSIGNED, Name VARCHAR(90), PRIMARY KEY(ID))",
        cur = self.chat.cursor()
        cur.execute("SELECT ID, Name FROM GameData")
        results = cur.fetchall()
        cur.close()
        if not results:
            print("Empty table: GameData")
            return

        cur = self.db.cursor()
        for tup in results:
            cur.execute("INSERT INTO GameData(ID, Name) VALUES (%s, %s)", tup)
        cur.close()
        self.db.commit()

    def upgrade_users(self):
        # "CREATE TABLE IF NOT EXISTS Users (Discord BIGINT UNSIGNED, Twitch VARCHAR(90), PRIMARY KEY(Discord))",
        cur = self.main.cursor()
        cur.execute("SELECT Discord, Twitch FROM Users")
        results = cur.fetchall()
        cur.close()
        if not results:
            print("Empty table: Users")
            return

        cur = self.db.cursor()
        for tup in results:
            cur.execute("INSERT INTO Users(Discord, Twitch) VALUES (%s, %s)", tup)
        cur.close()
        self.db.commit()

    def upgrade_points(self):
        # "CREATE TABLE IF NOT EXISTS Points (User BIGINT UNSIGNED, Count BIGINT UNSIGNED, PRIMARY KEY(User))",
        cur = self.main.cursor()
        cur.execute("SELECT User, Count FROM Points")
        results = cur.fetchall()
        cur.close()
        if not results:
            print("Empty table: Points")
            return

        cur = self.db.cursor()
        for tup in results:
            cur.execute("INSERT INTO Points(User, Count) VALUES (%s, %s)", tup)
        cur.close()
        self.db.commit()


upgrader = Upgrader(
    Configuration.DBUsername,
    Configuration.DBPassword,
    Configuration.DBName,
)
upgrader.drop()
upgrader.do()
