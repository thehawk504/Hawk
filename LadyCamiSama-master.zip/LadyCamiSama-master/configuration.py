from typing import Tuple, List, Dict
import sys
import json

DEFAULT_POINTS_STRING = "{user} Your rank: {rank}.\nYou have {points} points. {points_missing} for next rank ({next_rank})."
DEFAULT_ANNOUNCEMENT_STRING = "{channel} is live!"


class Configuration:
    _loaded = False
    OrchestratorGatherTime = None
    OrchestratorIterationsSavingInterval = None
    RoleDistributionInterval = None
    LiveCheckInterval = None
    RanksCheckInterval = 60
    ConnectedRefreshInterval = 1
    UserCommandsChannels = list()
    DBUsername = None
    DBPassword = None
    DBName = None
    WelcomeMessage = None
    WelcomeChannelID = None
    SystemChannelID = None
    LogChannelID = None
    LiveAnnouncementChannelID = None
    PointsString = DEFAULT_POINTS_STRING
    Roles = dict()
    PresencePoints = None
    ChattingPoints = None
    NoChannelsTime = 60
    PointsAttributionTime = 60
    PresenceMonitorTimeout = 1
    MaxTimeDiffOnline = 600
    MaxTimeDiffViewing = 400
    MaxTimeDiffChatting = 400
    TwitchChannelName = None
    AnnouncementString = None
    PointsChannels = list()

    @staticmethod
    def _init():
        if Configuration._loaded:
            return

        Configuration._loaded = True
        print("Loading configuration...")
        try:
            with open("config.json") as f:
                c = json.load(f)
            Configuration.OrchestratorGatherTime = c.get("orchestrator_gather_time", None)
            Configuration.OrchestratorIterationsSavingInterval = c.get("orchestration_iterations_before_saving", None)
            Configuration.RoleDistributionInterval = c.get("role_distribution_interval", None)
            Configuration.LiveCheckInterval = c.get("live_check_interval", None)
            Configuration.UserCommandsChannels = c.get("user_commands_channels", list())
            Configuration.TwitchAnnouncementChannelID = c.get("twitch_channel_name")
            Configuration.LogChannelID = c.get("log_channel", None)
            Configuration.SystemChannelID = c.get("system_channel", None)
            Configuration.WelcomeChannelID = c.get("welcome_channel", None)
            Configuration.WelcomeMessage = c.get("welcome_message", None)
            Configuration.LiveAnnouncementChannelID = c.get("live_channel", None)
            Configuration.DBUsername = c.get("db_username", None)
            Configuration.DBPassword = c.get("db_password", None)
            Configuration.DBName = c.get("db_name", None)
            Configuration.PointsString = c.get("points_string", Configuration.PointsString)
            Configuration.Roles = {int(role_id): percentage for role_id, percentage in c.get("roles", dict()).items()}
            Configuration.PresencePoints = c.get("presence_points", 0)
            Configuration.ChattingPoints = c.get("chatting_points", 0)
            Configuration.AnnouncementString = c.get("announcement_string", DEFAULT_ANNOUNCEMENT_STRING)
            Configuration.TwitchChannelName = c.get("twitch_channel_name")
            Configuration.PointsChannels = c.get("points_channel", list())

            if not all((
                    Configuration.OrchestratorGatherTime is not None,
                    Configuration.OrchestratorIterationsSavingInterval is not None,
                    Configuration.RoleDistributionInterval is not None,
                    Configuration.LiveCheckInterval is not None,
                    Configuration.DBName is not None,
                    Configuration.DBPassword is not None,
                    Configuration.DBUsername is not None,
                    Configuration.TwitchChannelName is not None,
                    Configuration.AnnouncementString is not None
            )):
                raise KeyError("Missing parameter.")

            print("--- CONFIGURATION ---")
            print("Gathering time for orchestrator:", Configuration.OrchestratorGatherTime)
            print("Iterations between saves:", Configuration.OrchestratorIterationsSavingInterval)
            print("Role distribution interval:", Configuration.RoleDistributionInterval)
            if not Configuration.PresencePoints:
                print("No presence points configuration")
            if not Configuration.ChattingPoints:
                print("No chatting points configuration")
            print("--- END CONFIGURATION ---")
            Configuration.save_config()
        except FileNotFoundError:
            Configuration.save_config()
            print("No configuration. Please edit config.json")
            sys.exit(1)
        except KeyError as e:
            Configuration.save_config()
            print("Missing parameter. Please edit config.json.")
            sys.exit(1)

    @staticmethod
    def save_config():
        with open("config.json", 'w') as f:
            json.dump({
                "orchestrator_gather_time": Configuration.OrchestratorGatherTime,
                "orchestration_iterations_before_saving": Configuration.OrchestratorIterationsSavingInterval,
                "role_distribution_interval": Configuration.RoleDistributionInterval,
                "roles": Configuration.Roles,
                "chatting_points": Configuration.ChattingPoints,
                "presence_points": Configuration.PresencePoints,
                "live_check_interval": Configuration.LiveCheckInterval,
                "user_commands_channels": Configuration.UserCommandsChannels,
                "db_username": Configuration.DBUsername,
                "db_password": Configuration.DBPassword,
                "db_name": Configuration.DBName,
                "welcome_message": Configuration.WelcomeMessage,
                "welcome_channel": Configuration.WelcomeChannelID,
                "log_channel": Configuration.LogChannelID,
                "live_channel": Configuration.LiveAnnouncementChannelID,
                "system_channel": Configuration.SystemChannelID,
                "twitch_channel_name": Configuration.TwitchChannelName,
                "points_string": Configuration.PointsString,
                "announcement_string": Configuration.AnnouncementString,
                "points_channel": Configuration.PointsChannels
            }, f)


class TwitchConfiguration:
    def __init__(self):
        try:
            with open("twitch.json") as f:
                j = json.load(f)

            self.username = j["username"]
            self.token = j["token"]
            self.client_id = j["client_id"]
            if ":" in self.token:
                self.password = self.token
            else:
                self.password = "oauth:{token}".format(token=self.token)

            assert self.username is not None, "Please configure twitch.json"
            assert self.password is not None, "Please configure twitch.json"
            assert self.client_id is not None, "Please configure twitch.json"
        except FileNotFoundError:
            with open("twitch.json", 'w') as f:
                json.dump({
                    "username": self.username,
                    "token": self.token,
                    "client_id": self.client_id
                }, f)
                print("Please configure twitch.json")
                sys.exit(1)


Configuration._init()
