import re
import socket
import time

from threading import Thread

from configuration import Configuration
from log import Log
from chat_info_storage import ChatStorage


class TwitchChatMonitor(Thread):
    ignored_codes = {'001', '002', '003', '004', '353', '366', '372', '376', '375', 'CAP', 'USERSTATE', 'ROOMSTATE'
                     'NOTICE', 'JOIN', 'CLEARCHAT', 'USERNOTICE'}
    ignored_words = {'USERSTATE', 'ROOMSTATE', 'NOTICE', 'JOIN', 'CLEARCHAT', 'USERNOTICE', 'HOSTTARGET'}

    def __init__(self, nick, password, channel, host="irc.twitch.tv", port=6667, name=None):
        Thread.__init__(self, name=name, daemon=True)
        # self.is_daemon = True

        self.channel = channel

        self.host = host
        self.nick = nick
        self.password = password
        self.port = port
        self.storage = None

        self.con = None

        self.last_message_timestamp = dict()
        self.last_join_timestamp = 0

    @staticmethod
    def chan_to_username(chan):
        chan = chan.lower()
        if chan.startswith("#"):
            return chan[1:]

        return chan

    def update_last_message(self, channel, user, timestamp=None):
        if timestamp is None:
            timestamp = time.time()

        if channel not in self.last_message_timestamp:
            self.last_message_timestamp[channel] = dict()

        if user not in self.last_message_timestamp[channel]:
            Log.info("Chat", "New user chatting in {}: {}".format(channel, user))

        self.last_message_timestamp[channel][user] = timestamp

    def on_message(self, channel, sender, message):
        channel = TwitchChatMonitor.chan_to_username(channel)

        if time.time() - self.storage.get_last_online(channel) <= Configuration.MaxTimeDiffOnline:
            self.update_last_message(channel, sender)

    def run(self):
        self.storage = ChatStorage()

        self.con = socket.socket()
        self.con.settimeout(15)
        self.con.connect((self.host, self.port))

        self.send_pass(self.password)
        self.send_nick(self.nick)
        self.send_tags()
        self.last_join_timestamp = 0

        self.join_channel(self.channel)

        data = ""
        while True:
            try:
                try:
                    data += self.con.recv(1024).decode('UTF-8')
                except UnicodeDecodeError as e:
                    Log.warning("Chat", "UnicodeDecodeError: {}".format(e))
                    print("UNICODE")
                    continue

                data_split = re.split(r"[~\r\n]+", data)
                data = data_split.pop()

                for line in data_split:
                    line = str.rstrip(line)
                    line = str.split(line)

                    if not line:
                        continue

                    if line[0] == 'PING':
                        Log.info("Chat", "Received ping on {}".format(self.name))
                        self.send_pong(line[1])
                    elif len(line) > 2 and line[2] == 'PRIVMSG':
                        sender = TwitchChatMonitor.get_sender(line[1])
                        message = TwitchChatMonitor.get_message(line)
                        channel = TwitchChatMonitor.get_channel(line)
                        self.on_message(channel, sender, message)
                    elif len(line) > 1 and (line[1] in TwitchChatMonitor.ignored_codes or line[1] in TwitchChatMonitor.ignored_words):
                        continue
                    elif len(line) > 2 and line[2] in TwitchChatMonitor.ignored_words:
                        continue
                    else:
                        if len(line) > 1:
                            print(line[1])
                        if len(line) > 2:
                            print(line[2])

            except (BrokenPipeError, socket.error) as e:
                pass

    def send_pong(self, msg):
        self.con.send(bytes('PONG %s\r\n' % msg, 'UTF-8'))

    def send_message(self, chan, msg):
        self.con.send(bytes('PRIVMSG %s :%s\r\n' % (chan, msg), 'UTF-8'))

    def send_nick(self, nick):
        self.con.send(bytes('NICK %s\r\n' % nick, 'UTF-8'))

    def send_pass(self, password):
        self.con.send(bytes('PASS %s\r\n' % password, 'UTF-8'))

    def send_tags(self):
        self.con.send(bytes('CAP REQ :twitch.tv/commands twitch.tv/tags\r\n', 'UTF-8'))

    def join_channel(self, chan):
        self.con.send(bytes('JOIN %s\r\n' % chan, 'UTF-8'))

    def part_channel(self, chan):
        self.con.send(self, bytes('PART %s\r\n' % chan, 'UTF-8'))

    @staticmethod
    def get_sender(msg):
        result = ""
        for char in msg:
            if char == "!":
                break
            if char != ":":
                result += char
        return result

    @staticmethod
    def get_message(msg):
        result = ""
        i = 4
        length = len(msg)
        while i < length:
            result += msg[i] + " "
            i += 1
        result = result.lstrip(':')
        return result

    @staticmethod
    def get_channel(msg):
        return msg[3]
