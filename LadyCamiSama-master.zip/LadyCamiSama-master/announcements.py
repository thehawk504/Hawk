import time
import sys
import asyncio

import discord
from discord.ext import commands

import utils

from configuration import Configuration
from chat_info_storage import ChatStorage
from twitch_utils import TwitchUtils


class LiveAnnouncementsCog(commands.Cog):
    def __init__(self, bot):
        self.bot: commands.Bot = bot
        self.guild: discord.Guild = None
        self.live_announcements_channel = None

        self.previously_live: bool = None

        self.storage = ChatStorage()
        self.twitch_utils = TwitchUtils()

    @commands.Cog.listener()
    async def on_ready(self):
        self.guild = self.bot.guilds[0]

        self.live_announcements_channel = self.guild.get_channel(Configuration.LiveAnnouncementChannelID)
        if not self.live_announcements_channel:
            print("Couldn't find live announcements channel {}".format(Configuration.LiveAnnouncementChannelID))

        loop = self.bot.loop
        task = loop.create_task(self.periodic())
        asyncio.ensure_future(task, loop=loop)

    async def periodic(self):
        while True:
            await self.announce_live()
            await asyncio.sleep(1)

    async def announce_live(self):
        last_online = self.storage.get_last_online(Configuration.TwitchChannelName)
        currently_live = time.time() - last_online <= Configuration.MaxTimeDiffOnline

        if currently_live == self.previously_live:
            return

        stream_title: str = self.storage.get_stream_title(Configuration.TwitchChannelName)
        if stream_title is None:
            return

        self.previously_live = currently_live

        if currently_live:
            await self.live_announcements_channel.send(Configuration.AnnouncementString.format(
                channel=Configuration.TwitchChannelName,
                game=self.twitch_utils.get_game_name(self.storage.get_current_game(Configuration.TwitchChannelName)),
                title=stream_title
            ))


def setup(bot):
    bot.add_cog(LiveAnnouncementsCog(bot))
