import datetime
import os
from enum import Enum

WriteLogsToFiles = True

Print = {
    # "Distribute": False,
    # "Chat": False,
    # "Presence": False,
    # "Orchestrator": False,
    # "Config": False,
    # "Points": False,
    # "Commands": False,
}
Write = {
    # "Distribute": True,
}

Min = "ERRR"


class Level(Enum):
    ERROR = 8
    WARNING = 4
    INFO = 2
    DEBUG = 1


class Log:
    @staticmethod
    def _init():
        Log.create_dir()

    @staticmethod
    def create_dir():
        if not os.path.isdir("Logs"):
            os.makedirs("Logs")

    @staticmethod
    def get_datetime():
        return datetime.datetime.now().strftime("%m/%d %H:%M:%S")

    @staticmethod
    def print(level, category, message):
        if category not in Print or Print[category]:
            if True or level == "ERRR":
                print("[{time}] [{level}] [{category}] {message}".format(
                    time=Log.get_datetime(),
                    category=category,
                    level=level,
                    message=message
                ))

        if WriteLogsToFiles:
            if category not in Write or Write[category]:
                with open("Logs/{}.log".format(category), 'a+') as f:
                    f.write("[{time}] [{level}] {message}\n".format(
                        time=Log.get_datetime(),
                        level=level,
                        message=message
                    ))

    @staticmethod
    def warning(category, message):
        Log.print("WARN", category, message)

    @staticmethod
    def info(category, message):
        Log.print("INFO", category, message)

    @staticmethod
    def debug(category, message):
        Log.print("DEBG", category, message)

    @staticmethod
    def error(category, message):
        Log.print("ERRR", category, message)


Log._init()
