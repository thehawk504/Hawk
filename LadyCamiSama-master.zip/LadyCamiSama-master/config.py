from discord.ext import commands
import discord

from configuration import Configuration
import utils
from log import Log
from typing import Union


class ConfigurationCog(commands.Cog):
    def __init__(self, bot):
        self.bot: commands.Bot = bot
        self.guild: discord.Guild = None

    @commands.Cog.listener()
    async def on_ready(self):
        self.guild = self.bot.guilds[0]

    @commands.command(aliases=["setpercentage"])
    async def addrole(self, ctx, role: Union[discord.Role, str], percentage: float):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        if isinstance(role, str):
            for r in self.guild.roles:
                if r.name.lower() == role.lower():
                    role = r
                    break
        if isinstance(role, str):
            await ctx.send("Couldn't find this role.")
            return

        Configuration.Roles[role.id] = percentage
        Configuration.save_config()
        await ctx.send("Added role {} for top {}%".format(role, percentage))

    @commands.command()
    async def removerole(self, ctx, role: Union[discord.Role, str]):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        if isinstance(role, str):
            for r in self.guild.roles:
                if r.name.lower() == role.lower():
                    role = r
                    break
        if isinstance(role, str):
            await ctx.send("Couldn't find this role.")
            return

        if role.id in Configuration.Roles:
            await ctx.send("Rank doesn't exist.")
            return

        Configuration.save_config()

        await ctx.send("Rank removed.")

    @commands.command()
    async def setchattingpoints(self, ctx, points: int):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        Configuration.ChattingPoints = points
        Configuration.save_config()
        await ctx.send("Set chatting points to {}".format(points))

    @commands.command(aliases=['setviewingpoints', 'setlurkingpoints', 'setwatchingpoints'])
    async def setpresencepoints(self, ctx, points: int):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        Configuration.PresencePoints = points
        Configuration.save_config()
        await ctx.send("Set presence points to {}".format(points))

    @commands.command(aliases=["ranks"])
    async def roles(self, ctx):
        m = "**Ranks:\n**"
        keys = list(Configuration.Roles.keys())
        keys.sort(key=lambda k: Configuration.Roles[k])
        for r in keys:
            percent = Configuration.Roles[r]
            m += "- {name} (top {percent}%)\n".format(
                name=self.guild.get_role(r).name,
                percent=percent
            )
        await ctx.send(m)

    @commands.command()
    async def setannouncement(self, ctx, *announcement_fmt):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        announcement_fmt = " ".join(announcement_fmt)

        Configuration.AnnouncementString = announcement_fmt
        Configuration.save_config()
        await ctx.send("Saved!")

    @commands.command()
    async def purge(self, ctx):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        await ctx.message.delete()
        await ctx.channel.purge()
        async for message in ctx.channel.history():
            await message.delete()

        await ctx.send("Purged", delete_after=3)

    @commands.command()
    async def setlogchannel(self, ctx, c: discord.TextChannel):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        Configuration.LogChannelID = c.id
        Configuration.save_config()
        self.bot.get_cog("WelcomeCog").log_channel = c
        await ctx.send("Saved {}".format(c.mention))

    @commands.command()
    async def setwelcomechannel(self, ctx, c: discord.TextChannel):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        Configuration.WelcomeChannelID = c.id
        Configuration.save_config()
        self.bot.get_cog("WelcomeCog").welcome_channel = c
        await ctx.send("Saved {}".format(c.mention))

    @commands.command()
    async def setannouncementschannel(self, ctx, c: discord.TextChannel):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        Configuration.LiveAnnouncementChannelID = c.id
        Configuration.save_config()
        self.bot.get_cog("LiveAnnouncementsCog").live_announcements_channel = c
        await ctx.send("Saved {}".format(c.mention))

    @commands.command()
    async def setsystemchannel(self, ctx, c: discord.TextChannel):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        Configuration.SystemChannelID = c.id
        Configuration.save_config()
        self.bot.get_cog("ScoreCog").system_channel = c
        await ctx.send("Saved {}".format(c.mention))

    @commands.command()
    async def addpointschannel(self, ctx, c: discord.TextChannel, points: int):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        if c.id not in Configuration.PointsChannels:
            Configuration.PointsChannels.append((c.id, points))
            Configuration.save_config()
            score_cog = self.bot.get_cog("ScoreCog")
            score_cog.points_channels.append(c)
            score_cog.points_for_channels[c] = points
            score_cog.last_messages[c] = dict()

        await ctx.send("Added {}".format(c.mention))

    @commands.command()
    async def removepointschannel(self, ctx, c: discord.TextChannel):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        if c.id not in map(lambda x: x[0], Configuration.PointsChannels):
            await ctx.send("This channel is not configured.")
            return

        i = None
        for i, (cid, _) in enumerate(Configuration.PointsChannels):
            if cid == c.id:
                break

        if i:
            del Configuration.PointsChannels[i]
            Configuration.save_config()
        score_cog = self.bot.get_cog("ScoreCog")
        score_cog.points_channels.remove(c)
        del score_cog.points_for_channels[c]
        del score_cog.last_messages[c]
        await ctx.send("OK")

    @commands.command()
    async def addcommandschannel(self, ctx, c: discord.TextChannel):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        Configuration.UserCommandsChannels.append(c.id)
        Configuration.save_config()
        await ctx.send("Added")

    @commands.command()
    async def removecommandschannel(self, ctx, c: discord.TextChannel):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        if c.id not in Configuration.UserCommandsChannels:
            await ctx.send("This channel is not configured.")
            return

        Configuration.UserCommandsChannels.remove(c.id)
        Configuration.save_config()
        await ctx.send("Removed")


def setup(bot):
    bot.add_cog(ConfigurationCog(bot))
