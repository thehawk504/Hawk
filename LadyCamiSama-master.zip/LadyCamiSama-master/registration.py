from discord.ext import commands
import discord

from main_storage import MainStorage
from chat_info_storage import ChatStorage
from configuration import Configuration

import utils
from log import Log


class RegistrationCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.guild = None
        self.storage = ChatStorage()
        self.main_storage = MainStorage()

    @commands.Cog.listener()
    async def on_ready(self):
        self.guild = self.bot.guilds[0]

    @commands.command()
    async def twitch(self, ctx, username=None):
        if username is None:
            await ctx.send("Usage: `!twitch <username>`")
            return

        if username.startswith("<"):
            username = username[1:]
        if username.endswith(">"):
            username = username[:-1]

        if not username:
            await ctx.send("Usage: `!twitch <username>`")
            return

        author: discord.Member = ctx.message.author
        if self.main_storage.get_twitch_username(author.id):
            await ctx.send("{} You're already registered!".format(author.mention))
            return

        self.main_storage.add_user(author.id, username.lower())
        await ctx.send("{} I saved your username!".format(author.mention))
        try:
            await author.edit(nick=username)
        except discord.errors.Forbidden:
            pass

    @commands.command()
    async def unregister(self, ctx, user: discord.Member = None):
        if not utils.is_admin(ctx) and not utils.is_developer(ctx):
            await ctx.message.delete()
            return

        if user is None:
            user = ctx.message.author

        self.main_storage.reset_twitch_username(user.id)
        try:
            await user.edit(nick=None)
        except discord.errors.Forbidden:
            Log.warning("Registration", "Couldn't edit {}'s nickname.".format(user))
        await ctx.send("OK")

    @commands.Cog.listener()
    async def on_member_leave(self, member: discord.Member):
        self.main_storage.delete_data(member.id)

    @commands.command()
    async def rank(self, ctx):
        author = ctx.message.author
        roles = dict()

        # Get all the roles in configuration
        for role_id in Configuration.PresencePoints:
            roles[role_id] = self.guild.get_role(role_id)
        for role_id in Configuration.ChattingPoints:
            if role_id not in roles:
                roles[role_id] = self.guild.get_role(role_id)

        available_roles = sorted(
            [role for role in author.roles if role.id in Configuration.PresencePoints],
            key=lambda role: Configuration.PresencePoints[role_id],
            reverse=True
        )
        if not available_roles:
            await ctx.send("You have no rank.")
        else:
            await ctx.send("Your rank: {}".format(available_roles[0]))

    @commands.command()
    async def resetall(self, ctx):
        if not utils.is_admin(ctx):
            await ctx.message.delete()
            return

        self.main_storage.reset_all_points()
        await ctx.send("All points have been reset.")


def setup(bot: commands.Bot):
    bot.add_cog(RegistrationCog(bot))
