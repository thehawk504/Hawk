import asyncio
import time

import discord
from discord.ext import commands

import utils
from log import Log

from configuration import Configuration
from main_storage import MainStorage
from chat_info_storage import ChatStorage


class Distribute(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.guild = None

        self.unregistered_role: discord.Role = None
        self.special_role: discord.Role = None
        self.system_channel: discord.TextChannel = None
        self.twitch_storage = ChatStorage()
        self.main_storage = MainStorage()

        self.leaderboard_rank = dict()
        self.leaderboard_count = 0

    @commands.Cog.listener()
    async def on_ready(self):
        self.guild = self.bot.guilds[0]

        await self.reload_config()

        loop = self.bot.loop
        task = loop.create_task(self.periodic())
        asyncio.ensure_future(task, loop=loop)

    async def reload_config(self):
        for r in self.guild.roles:
            if r.name.lower() == "unregistered":
                self.unregistered_role = r

        if self.unregistered_role is None:
            self.unregistered_role = await self.guild.create_role(
                name="Unregistered",
                reason="Unregistered role couldn't be found."
            )

        if Configuration.SystemChannelID:
            self.system_channel = self.guild.get_channel(Configuration.SystemChannelID)

    async def periodic(self):
        iterations = 0
        while True:
            if iterations % Configuration.RoleDistributionInterval == 0:
                await self.redistribute_roles()

            iterations += 1
            await asyncio.sleep(1)

    @commands.command()
    async def forcedis(self, ctx):
        await ctx.message.delete()

        if not utils.is_developer(ctx):
            Log.info("Distribute", "forcedis usage denied to {}".format(ctx.message.author))
            return

        try:
            await self.bot.request_offline_members(self.guild)
        except discord.errors.InvalidArgument:
            pass
        await ctx.message.author.send("Forcing role refresh.")
        roles = [self.guild.get_role(role_id) for role_id in Configuration.Roles]
        for m in self.guild.members:
            if m.id == self.bot.user.id:
                continue

            for r in roles:
                if r in m.roles:
                    await m.remove_roles(r, reason="Roles redistribution")
                if self.unregistered_role in m.roles:
                    await m.remove_roles(self.unregistered_role, reason="Roles redistribution")

        await self.redistribute_roles()
        await ctx.message.author.send("OK")

    async def redistribute_roles(self):
        scores = self.main_storage.get_points_dict()
        roles = {percent: self.guild.get_role(role_id) for role_id, percent in Configuration.Roles.items()}
        members = list()
        for member in self.guild.members:
            if member.id == self.bot.user.id:
                continue

            tuser = self.main_storage.get_twitch_username(member.id)
            if not tuser:
                if self.unregistered_role not in member.roles:
                    await member.add_roles(self.unregistered_role, reason="Member not registered.")
                for r in roles.values():
                    if r in member.roles:
                        await member.remove_roles(r, reason="Member not registered.")
                continue
            else:
                if self.unregistered_role in member.roles:
                    await member.remove_roles(self.unregistered_role, reason="Member registered.")

            members.append(member)
            if member.id not in scores:
                scores[member.id] = 0

        if not members:
            Log.warning("Distribute", "No member to distribute roles to.")
            return

        if not Configuration.Roles:
            Log.warning("Distribute", "No roles configured!")
            return

        members.sort(key=lambda m: scores[m.id])
        members_added = 0
        percentages = list(sorted(roles.keys()))

        for i, member in enumerate(reversed(members)):
            self.leaderboard_rank[member.id] = i + 1

        self.leaderboard_count = len(members)
        for percentage in percentages:
            while members_added / self.leaderboard_count <= percentage / 100 and \
                    (members and (scores[members[-1].id] > 0 or percentage == 100)):
                if not members:
                    break

                member = members.pop()
                members_added += 1

                if self.special_role and self.special_role in member.roles:
                    continue

                if roles[percentage] not in member.roles:
                    if self.system_channel:
                        old_role: discord.Role = None
                        old_percentage: float = None
                        for p, r in roles.items():
                            if r in member.roles:
                                old_percentage = p
                                old_role = r
                                break

                        if old_percentage:
                            if percentage > old_percentage:
                                await self.system_channel.send("{user} you were demoted from {from_} to {to}!".format(
                                    user=member.mention,
                                    from_=old_role,
                                    to=roles[percentage]
                                ))
                            else:
                                await self.system_channel.send("{user} you were promoted from {from_} to {to}!".format(
                                    user=member.mention,
                                    from_=old_role,
                                    to=roles[percentage]
                                ))

                    try:
                        await member.remove_roles(*roles.values(), reason="Role redistribution (score changed)")
                        await member.add_roles(roles[percentage], reason="Entered in Top {}%".format(percentage))
                    except (discord.errors.Forbidden, discord.errors.NotFound):
                        Log.error("Distribute", "Couldn't update roles for {} (FORBIDDEN)".format(member))


def setup(bot):
    bot.add_cog(Distribute(bot))
