import json
import time

import requests
from requests import Session

from chat_info_storage import ChatStorage
from log import Log
from configuration import TwitchConfiguration


class TwitchUtils:
    URL = "https://api.twitch.tv/helix/streams"

    def __init__(self):
        self.session = Session()
        self.storage = ChatStorage()
        self.configuration = TwitchConfiguration()

    def channels_online(self, channel_names):
        result = {channel: (False, 0, -1, None) for channel in channel_names}

        url = TwitchUtils.URL + "?user_login=" + "&user_login=".join(channel_names)
        try:
            req = self.session.get(
                url,
                headers={
                    "Client-ID": self.configuration.client_id
                }
            )
            resp = req.json()
        except requests.exceptions.ConnectionError:
            Log.warning("Utils", "channels_online: Connection error.")
            time.sleep(3)
            # Reset session
            self.session = Session()
            return self.channels_online(channel_names)
        except json.JSONDecodeError:
            resp = dict()

        if "data" not in resp:
            if resp.get("error", None) == "Too Many Requests":
                Log.error("Utils", "channels_online: Too many requests.")
            else:
                Log.error("Utils", req.headers)
                Log.error("Utils", resp)
            return result

        for channel_data in resp["data"]:
            channel = channel_data["user_name"].lower()
            result[channel] = True, channel_data["viewer_count"], channel_data["game_id"], channel_data["title"]

        return result

    def get_game_name(self, game_id):
        if isinstance(game_id, tuple):
            game_id = game_id[0]

        game_id = int(game_id)
        if game_id == 0:
            return None

        name = self.storage.get_game_name(game_id)

        if name:
            return name

        URL = "https://api.twitch.tv/helix/games"
        try:
            req = self.session.get(
                URL,
                headers={
                    "Client-ID": self.configuration.client_id
                },
                params={
                    "id": game_id
                }
            )
            resp = req.json()
        except requests.exceptions.ConnectionError:
            Log.warning("Utils", "get_game_name: Connection error.")
            time.sleep(3)
            # Reset session
            self.session = Session()
            return self.get_game_name(game_id)
        except json.JSONDecodeError:
            Log.error("Utils", "get_game_name: Wrong JSON data '{}'".format(req.text))
            return "[Fetching game name...]"

        if "data" not in resp:
            if resp.get("error", None) == "Too Many Requests":
                Log.error("Utils", "get_game_name: Too many requests.")
            else:
                Log.error("Utils", req.headers)
                Log.error("Utils", resp)
            return "[Fetching game name...]"

        name = resp["data"][0]["name"]
        self.storage.set_game_name(game_id, name)

        return name


if __name__ == '__main__':
    utils = TwitchUtils()
    print(utils.channels_online(["mrtweeday"]))
