import time

import mysql.connector

from configuration import Configuration
from log import Log


class ChatStorage:
    # Channel -> User -> Timestamp
    last_messages = dict()
    last_presences = dict()
    last_online = dict()
    stream_titles = dict()
    current_game = dict()
    viewers_count = dict()
    game_names = dict()
    loaded_cache = False

    def __init__(self):
        self.db = None

        self._init()
        if not ChatStorage.loaded_cache:
            ChatStorage.loaded_cache = True
            self.load_cache()

    def _init(self):
        try:
            self.db = mysql.connector.connect(
                host="localhost",
                user=Configuration.DBUsername,
                passwd=Configuration.DBPassword,
                database=Configuration.DBName
            )

        except mysql.connector.errors.ProgrammingError as e:
            if "1049" in str(e):
                db = mysql.connector.connect(
                    host="localhost",
                    user=Configuration.DBUsername,
                    passwd=Configuration.DBPassword
                )
                cur = db.cursor()
                cur.execute("CREATE DATABASE {}".format(Configuration.DBName))
                cur.close()
                db.close()
                return self._init()
            else:
                Log.error("Storage", "Unexpected error: {}".format(e))
                raise e

    def get_cursor(self, retry=True):
        try:
            cursor = self.db.cursor()
            return cursor
        except Exception as e:
            if retry:
                self.db = mysql.connector.connect(
                    host="localhost",
                    user=Configuration.DBUsername,
                    passwd=Configuration.DBPassword,
                    database=Configuration.DBName
                )
                return self.get_cursor(retry=False)
            else:
                raise e

    def load_cache(self):
        SQL = "SELECT User, Channel, Message FROM Messages"
        cur = self.get_cursor()
        cur.execute(SQL)
        results = cur.fetchall()
        self.db.commit()
        cur.close()

        for _, channel, _ in results:
            ChatStorage.last_messages[channel] = dict()

        for user, channel, timestamp in results:
            ChatStorage.last_messages[channel][user] = timestamp

        SQL = "SELECT User, Channel, Timestamp FROM Presence"
        cur = self.get_cursor()
        cur.execute(SQL)
        results = cur.fetchall()
        self.db.commit()
        cur.close()

        for _, channel, _ in results:
            ChatStorage.last_presences[channel] = dict()

        for user, channel, timestamp in results:
            ChatStorage.last_presences[channel][user] = timestamp

        SQL = "SELECT Channel, Timestamp FROM Online"
        cur = self.get_cursor()
        cur.execute(SQL)
        results = cur.fetchall()
        self.db.commit()
        cur.close()

        for channel, timestamp in results:
            ChatStorage.last_online[channel] = timestamp

        SQL = "SELECT Channel, Viewers FROM Viewers"
        cur = self.get_cursor()
        cur.execute(SQL)
        results = cur.fetchall()
        self.db.commit()
        cur.close()

        for channel, count in results:
            ChatStorage.viewers_count[channel] = count

        SQL = "SELECT ID, Name FROM GameData"
        cur = self.get_cursor()
        cur.execute(SQL)
        results = cur.fetchall()
        self.db.commit()
        cur.close()
        for game, name in results:
            ChatStorage.game_names[game] = name

    ########### LATEST MESSAGE TIMESTAMP #############

    def _update_latest_message_cache(self, user, channel, timestamp):
        if channel not in ChatStorage.last_messages:
            ChatStorage.last_messages[channel] = dict()

        ChatStorage.last_messages[channel][user] = timestamp

    def _update_latest_message_db(self, user, channel, timestamp):
        SQL_I = "INSERT INTO Messages (User, Channel, Message) VALUES (%s, %s, %s)"
        SQL_U = "UPDATE Messages SET Message = %s WHERE User = %s AND Channel = %s"
        try:
            cur = self.get_cursor()
            cur.execute(SQL_I, (user, channel, timestamp))
        except mysql.connector.IntegrityError:
            cur = self.get_cursor()
            cur.execute(SQL_U, (timestamp, user, channel))
        cur.close()
        self.db.commit()

    def update_latest_message(self, user, channel, timestamp):
        self._update_latest_message_cache(user, channel, timestamp)
        self._update_latest_message_db(user, channel, timestamp)

    def _get_latest_message_db(self, user, channel):
        SQL = "SELECT Message FROM Messages WHERE User = %s AND Channel = %s ORDER BY Message DESC LIMIT 1"
        cur = self.get_cursor()
        cur.execute(SQL, (user, channel))
        results = cur.fetchone()
        self.db.commit()
        cur.close()
        if not results:
            return 0

        timestamp, = results

        if channel not in ChatStorage.last_messages:
            ChatStorage.last_messages[channel] = dict()

        ChatStorage.last_messages[channel][user] = timestamp
        return timestamp

    def get_latest_messsage(self, user, channel):
        if channel in ChatStorage.last_messages and user in ChatStorage.last_messages[channel]:
            return ChatStorage.last_messages[channel][user]

        return self._get_latest_message_db(user, channel)

    ############## LATEST PRESENCE #############

    def _update_latest_presence_cache(self, user, channel, timestamp):
        if channel not in ChatStorage.last_presences:
            ChatStorage.last_presences[channel] = dict()

        ChatStorage.last_presences[channel][user] = timestamp

    def _update_latest_presence_db(self, user, channel, timestamp):
        SQL_I = "INSERT INTO Presence (User, Channel, Timestamp) VALUES (%s, %s, %s)"
        SQL_U = "UPDATE Presence SET Timestamp = %s WHERE User = %s AND Channel = %s"
        cur = self.get_cursor()
        try:
            cur.execute(SQL_I, (user, channel, timestamp))
        except mysql.connector.IntegrityError:
            cur.execute(SQL_U, (timestamp, user, channel))
            cur.close()
        self.db.commit()

    def update_latest_presence(self, user, channel, timestamp):
        self._update_latest_presence_cache(user, channel, timestamp)
        self._update_latest_presence_db(user, channel, timestamp)

    def _get_latest_presence_db(self, user, channel):
        SQL = "SELECT Timestamp FROM Presence WHERE User = %s AND Channel = %s ORDER BY Timestamp DESC LIMIT 1"
        cur = self.get_cursor()
        cur.execute(SQL, (user, channel))
        results = cur.fetchone()
        cur.close()
        if not results:
            return 0

        timestamp, = results

        if channel not in ChatStorage.last_presences:
            ChatStorage.last_presences[channel] = dict()

        ChatStorage.last_presences[channel][user] = timestamp
        return timestamp

    def get_latest_presence(self, user, channel):
        if channel in ChatStorage.last_presences and user in ChatStorage.last_presences[channel]:
            return ChatStorage.last_presences[channel][user]

        return self._get_latest_presence_db(user, channel)

    ############ VIEWERS #############

    def _update_viewers_cache(self, channel, count):
        ChatStorage.viewers_count[channel] = count

    def _update_viewers_db(self, channel, count):
        SQL_I = "INSERT INTO Viewers (Channel, Viewers) VALUES (%s, %s)"
        SQL_U = "UPDATE Viewers SET Viewers = %s WHERE Channel = %s"
        cur = self.get_cursor()
        try:
            cur.execute(SQL_I, (channel, count))
        except mysql.connector.IntegrityError:
            cur.execute(SQL_U, (count, channel))
        cur.close()
        self.db.commit()

    def update_viewers_count(self, channel, count):
        self._update_viewers_cache(channel, count)
        self._update_viewers_db(channel, count)

    def _get_viewers_count_db(self, channel):
        SQL = "SELECT Viewers FROM Viewers WHERE Channel = %s"
        cur = self.get_cursor()
        cur.execute(SQL, (channel,))
        results = cur.fetchone()
        self.db.commit()
        cur.close()
        if not results:
            return 0

        count, = results

        ChatStorage.viewers_count[channel] = count
        return count

    def get_viewers_count(self, channel):
        if channel in ChatStorage.viewers_count:
            return ChatStorage.viewers_count[channel]

        return self._get_viewers_count_db(channel)

    ############ LAST ONLINE #############

    def _update_last_online_cache(self, channel, timestamp):
        ChatStorage.last_online[channel] = timestamp

    def _update_last_online_db(self, channel, timestamp):
        SQL_I = "INSERT INTO Online (Channel, Timestamp) VALUES (%s, %s)"
        SQL_U = "UPDATE Online SET Timestamp = %s WHERE Channel = %s"
        cur = self.get_cursor()
        try:
            cur.execute(SQL_I, (channel, timestamp))
        except mysql.connector.IntegrityError:
            cur.execute(SQL_U, (timestamp, channel))
        self.db.commit()
        cur.close()

    def update_last_online(self, channel, timestamp):
        self._update_last_online_cache(channel, timestamp)
        self._update_last_online_db(channel, timestamp)

    def _get_last_online_db(self, channel):
        SQL = "SELECT Timestamp FROM Online WHERE Channel = %s"
        cur = self.get_cursor()
        cur.execute(SQL, (channel,))
        results = cur.fetchone()
        self.db.commit()
        cur.close()
        if not results:
            return 0

        timestamp, = results

        ChatStorage.last_online[channel] = timestamp
        return timestamp

    def get_last_online(self, channel):
        if channel in ChatStorage.last_online:
            return ChatStorage.last_online[channel]

        return self._get_last_online_db(channel)

    ############ LATEST GAMES #########

    def _update_latest_game_cache(self, channel, game):
        ChatStorage.current_game[channel] = game

    def _update_latest_game_db(self, channel, game):
        SQL_I = "INSERT INTO Games (Channel, Game) VALUES (%s, %s)"
        SQL_U = "UPDATE Games SET Game = %s WHERE Channel = %s"
        cur = self.get_cursor()
        try:
            cur.execute(SQL_I, (channel, game))
        except mysql.connector.IntegrityError:
            cur.execute(SQL_U, (game, channel))
        self.db.commit()
        cur.close()

    def update_latest_game(self, channel, game):
        self._update_latest_game_cache(channel, game)
        self._update_latest_game_db(channel, game)

    def _get_current_game_db(self, channel):
        SQL = "SELECT Game FROM Games WHERE Channel = %s"
        cur = self.get_cursor()
        cur.execute(SQL, (channel,))
        results = cur.fetchone()
        self.db.commit()
        cur.close()
        if not results:
            return 0

        game = results

        ChatStorage.current_game[channel] = game
        return game

    def get_current_game(self, channel):
        if channel in ChatStorage.current_game:
            return ChatStorage.current_game[channel]

        return self._get_current_game_db(channel)

    ########### GAME DATA ############

    def _get_game_name_db(self, game_id):
        assert (isinstance(game_id, int))
        SQL = "SELECT Name FROM GameData WHERE ID = %s"
        cur = self.get_cursor()
        cur.execute(SQL, (game_id,))
        result = cur.fetchone()
        self.db.commit()
        cur.close()
        if not result:
            return None

        name = result[0]
        ChatStorage.game_names[game_id] = name
        return name

    def get_game_name(self, game_id):
        if isinstance(game_id, tuple):
            game_id = game_id[0]

        game_id = int(game_id)
        name = ChatStorage.game_names.get(game_id, None)
        if name:
            return name

        return self._get_game_name_db(game_id)

    def set_game_name(self, game_id, name):
        SQL = "INSERT INTO GameData (ID, Name) VALUES (%s, %s)"

        if isinstance(game_id, tuple):
            game_id = int(game_id[0])
        game_id = int(game_id)

        ChatStorage.game_names[game_id] = name
        try:
            cur = self.get_cursor()
            cur.execute(SQL, (game_id, name))
            cur.close()
            self.db.commit()
        except mysql.connector.IntegrityError as e:
            Log.error("Storage", "Exception while setting name: {}".format(repr(e)))
        except Exception as e:
            Log.error("Storage", "Couldn't set game name: {}".format(repr(e)))

    ########## GENERAL ##############

    def _get_current(self, to_filter, username, max_time: int):
        matches = list()
        now = time.time()
        for channel_name, presence_data in to_filter.items():
            if username in presence_data:
                timestamp = presence_data[username]
                if now - timestamp <= max_time:
                    if channel_name.startswith("#"):
                        channel_name = channel_name[1:]
                    matches.append(channel_name)

        return matches

    def get_current_viewers(self, max_time: int):
        SQL = "SELECT User, Timestamp FROM Presence WHERE Timestamp >= {}".format(time.time() - max_time)
        cur = self.db.cursor()
        cur.execute(SQL)
        results = cur.fetchall()
        self.db.commit()
        if not results:
            return list()
        cur.close()
        return list(map(lambda x: x[0], results))

    def get_current_chatters(self, max_time: int):
        SQL = "SELECT User, Message FROM Messages WHERE Message >= {}".format(time.time() - max_time)
        cur = self.db.cursor()
        cur.execute(SQL)
        results = cur.fetchall()
        self.db.commit()
        if not results:
            return list()
        cur.close()
        return list(map(lambda x: x[0], results))

    def get_current_presence(self, username, max_time: int):
        return self._get_current(ChatStorage.last_presences, username, max_time)

    def get_current_chatting(self, username, max_time: int):
        return self._get_current(ChatStorage.last_messages, username, max_time)

    def get_current_viewers_count(self, channel_name, max_time: int):
        if not channel_name in ChatStorage.last_presences:
            return 0

        count = 0
        now = time.time()
        for _, timestamp in ChatStorage.last_presences[channel_name].items():
            if now - timestamp <= max_time:
                count += 1

        return count

    def set_stream_title(self, channel, title):
        ChatStorage.stream_titles[channel] = title

    def get_stream_title(self, channel):
        return ChatStorage.stream_titles.get(channel, None)
